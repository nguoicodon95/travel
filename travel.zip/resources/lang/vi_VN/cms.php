<?php

return [
    'requestCompleted' => 'Yêu cầu được thực hiện thành công',
    'requestNotCompleted' => 'Yêu cầu chưa được thực hiện',

    'page' => 'Trang',
];