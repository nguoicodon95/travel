<?php
return [
    'sent' => 'Yêu cầu thay đổi mật khẩu được gửi thành công',
    'reset' => 'Bạn đã thay đổi mật khẩu thành công',
    'user' => 'User không tồn tại',
    'password' => 'Password không đúng',
    'token' => 'Sai token',
];