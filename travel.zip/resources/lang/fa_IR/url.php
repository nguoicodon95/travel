<?php
return [
    'post' => 'پست',
    'category' => 'دسته بندی',
    'product' => 'محصول',
    'productCategory' => 'دسته بندی محصولات',
];
