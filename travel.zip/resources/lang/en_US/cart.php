<?php
return [
    'addCartError' => 'Some error occurred when add to cart',
    'maxQuantityError' => 'The numbers of product in shopping cart has reached the limit',
    'productNotExistsInCart' => 'Product not exists in cart',
    'updateCartCompleted' => 'Add to cart completed',
];