<?php
return [
    'sent' => 'Your request has been sent',
    'reset' => 'Your password has been reset',
    'user' => 'Invalid user',
    'password' => 'Invalid password',
    'token' => 'Invalid token',
];