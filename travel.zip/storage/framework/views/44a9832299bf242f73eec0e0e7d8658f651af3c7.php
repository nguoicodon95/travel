<?php if(isset($categories) && $categories->count() > 0): ?>
    <ul class="list-item">
        <?php foreach($categories as $key => $row): ?>
            <li>
                <a href="#" data-title="<?php echo e(isset($row->title) ? $row->title : ''); ?>" data-relatedid="<?php echo e(isset($row->id) ? $row->id : ''); ?>" data-type="<?php echo e(isset($type) ? $type : 'category'); ?>"><?php echo e(isset($row->title) ? $row->title : ''); ?></a>
                <?php echo $__env->make('admin._partials.menu._categories-select-src', ['categories' => $row->child()->where('status', '=', 1)->get(), 'type' => $type], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            </li>
        <?php endforeach; ?>
    </ul>
<?php endif; ?>