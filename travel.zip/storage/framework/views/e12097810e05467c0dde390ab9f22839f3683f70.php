<?php $__env->startSection('css'); ?>
<style media="screen">
  .controls {
    display: block !important;
  }
  .post-in-catalog .description {
    font-size: 13px;
    height: 55px;
    overflow-y: auto;
  }
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="section">
    <div class="container">
    <?php if(!empty($catalog_child)): ?>
      <?php foreach($catalog_child as $key => $catalog): ?>
        <div class="row">
            <div class="col-md-9">
                <h2><?php echo e($key); ?></h2>
            </div>
            <div class="col-md-3">
                <!-- Controls -->
                <div class="controls pull-right crsl-nav" id="carosel<?php echo e(str_slug($key)); ?>">
                    <a class="left fa fa-chevron-left previous" href="#" data-slide="prev"></a>
                    <a class="right fa fa-chevron-right next" href="#" data-slide="next"></a>
                </div>
            </div>
        </div>
        <div class="gallery<?php echo e(str_slug($key)); ?> crsl-items" data-navigation="carosel<?php echo e(str_slug($key)); ?>">
            <div class="crsl-wrap">
              <?php $__empty_1 = true; foreach($catalog as $child): $__empty_1 = false; ?>
                <div class="crsl-item">
                    <div class="thumbnail">
                        <a href="<?php echo e(_getCategoryLinkWithParentSlugs($child->id)); ?>">
                            <img class="image-background image-full" src="/images/libraries/trans.png" style="background-image: url('<?php echo e($child->thumbnail); ?>');" alt="<?php echo e($child->title); ?>" title="<?php echo e($child->title); ?>" />
                        </a>
                    </div>
                    <h3><a href="<?php echo e(_getCategoryLinkWithParentSlugs($child->id)); ?>"><?php echo e($child->title); ?></a></h3>
                </div>
              <?php endforeach; if ($__empty_1): ?>
                <p>No catalog for section</p>
              <?php endif; ?>
            </div>
        </div>
        <script>
            jQuery(document).ready(function($){
                $('.gallery<?php echo e(str_slug($key)); ?>').carousel({ visible: 3, itemMargin: 10, itemMinWidth: 300 });
            });
        </script>
      <?php endforeach; ?>
    <?php endif; ?>
    </div>
</div>
<div class="section bg-grey">
    <div class="container">
        <div class="row">
            <div class="col-md-9">
                <h2>VOYAGES PRÉFÉRÉS</h2>
            </div>
            <div class="col-md-3">
                <!-- Controls -->
                <div class="controls pull-right crsl-nav" id="carosel-fav">
                    <a class="left fa fa-chevron-left previous" href="#carousel-prev" data-slide="prev"></a>
                    <a class="right fa fa-chevron-right next" href="#carousel-next" data-slide="next"></a>
                </div>
            </div>
        </div>
        <div class="gallery-fav crsl-items" data-navigation="carosel-fav">
            <div class="crsl-wrap">
                <?php if(!empty($post_favourite)): ?>
                  <?php foreach($post_favourite as $post): ?>
                  <div class="crsl-item">
                      <div class="thumbnail">
                          <a href="<?php echo e(_getPostLink($post->slug)); ?>">
                            <img class="image-background image-full" src="/images/libraries/trans.png" style="background-image: url('<?php echo e($post->thumbnail); ?>');" alt="<?php echo e($post->title); ?>" title="<?php echo e($post->title); ?>" />
                          </a>
                      </div>
                      <h3 class="voyage-title">
                          <a href=""><?php echo e($post->title); ?>

                              <span class="fa fa-angle-right"></span>
                          </a>
                      </h3>
                  </div>
                  <?php endforeach; ?>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>
<div class="section reset-padding-bottom">
    <div class="container">
        <div class="row">
            <div class="col-md-7">
                <h4 class="about-title"><?php echo e(isset($customfield['title']) ? $customfield['title'] : ''); ?></h4>
                <div class="about-content"><?php echo isset($customfield['body']) ? $customfield['body'] : ''; ?></div>
                <div class="about-bottom">
                    <div class="row">
                        <div class="col-md-9 reset-padding-right">
                            <h5>Si Vous ne trouvez pas ce que vous cherchez?</h5>
                        </div>
                        <div class="col-md-3">
                            <a class="btn btn-success" href="/contact">Ecrivez nous</a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-5">
                <div class="voy-in-view">
                    <div class="row">
                        <div class="col-md-12">
                          <?php foreach($customfield['about_post'] as $post): ?>
                            <div class="thumbnail">
                                <a href="<?php echo e($post['link']); ?>">
                                    <img class="image-background image-full" src="/images/libraries/trans.png" style="background-image: url(<?php echo e(isset($post['image']) ? $post['image'] : ''); ?>)" />
                                </a>
                            </div>
                          <?php endforeach; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <hr>
    </div>
</div>
<div class="section post-in-catalog">
    <div class="container">
    <?php if(!empty($post_in_cate)): ?>
      <?php foreach($post_in_cate as $row): ?>
        <div class="row">
            <div class="col-md-9">
                <h2><a href="<?php echo e(_getCategoryLinkWithParentSlugs($row['id'])); ?>"><?php echo e($row['title']); ?></a></h2>
            </div>
            <div class="col-md-3">
                <!-- Controls -->
                <div class="controls pull-right crsl-nav" id="carosel<?php echo e(str_slug($row['title'])); ?>">
                    <a class="left fa fa-chevron-left previous" href="#" data-slide="prev"></a>
                    <a class="right fa fa-chevron-right next" href="#" data-slide="next"></a>
                </div>
            </div>
        </div>
        <div class="gallery<?php echo e(str_slug($row['title'])); ?> crsl-items" data-navigation="carosel<?php echo e(str_slug($row['title'])); ?>">
            <div class="crsl-wrap">
              <?php $__empty_1 = true; foreach($row['posts'] as $post): $__empty_1 = false; ?>
                <div class="crsl-item">
                    <div class="thumbnail">
                        <a href="<?php echo e(_getPostLink($post->slug)); ?>">
                            <img class="image-background image-full" src="/images/libraries/trans.png" style="background-image: url('<?php echo e($post->thumbnail); ?>');" alt="<?php echo e($post->title); ?>" title="<?php echo e($post->title); ?>" />
                        </a>
                    </div>
                    <h3><a href="<?php echo e(_getPostLink($post->slug)); ?>"><?php echo e($post->title); ?></a></h3>
                    <div class="description">
                        <?php echo e($post->description); ?>

                    </div>
                </div>
              <?php endforeach; if ($__empty_1): ?>
                <p>No catalog for section</p>
              <?php endif; ?>
            </div>
        </div>
        <script>
            jQuery(document).ready(function($){
                $('.gallery<?php echo e(str_slug($row['title'])); ?>').carousel({ visible: 3, itemMargin: 10, itemMinWidth: 300 });
            });
        </script>
      <?php endforeach; ?>
    <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script src="/third_party/carousel/responsiveCarousel.min.js"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js-init'); ?>
<script>
    jQuery(document).ready(function($){
        $('.gallery-fav').carousel({ visible: 3, itemMargin: 10, itemMinWidth: 300 });
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('front._master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>