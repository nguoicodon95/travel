<?php
$child = '';
for ($i = 0; $i < $childText; $i++) {
    $child .= '——';
}
?>
<?php foreach($categories as $key => $row): ?>
    <option value="<?php echo e(isset($row->id) ? $row->id : ''); ?>" <?php echo e((($row->id == (int) $selectedNode) ? ' selected="selected"' : '')); ?>><?php echo e($child . $row->global_title); ?></option>
    <?php echo $__env->make('admin._partials.custom-fields._categories-selectbox', ['categories' => $row->child()->get(), 'childText' => ($childText + 1), 'selectedNode' => $selectedNode], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php endforeach; ?>