
<!DOCTYPE html>
<!--[if IE 8]>
<html lang="<?php echo e(isset($currentLanguageCode) ? $currentLanguageCode : 'en'); ?>" class="ie8 no-js <?php echo e(($showHeaderAdminBar) ? 'show-admin-bar' : ''); ?>"> <![endif]-->
<!--[if IE 9]>
<html lang="<?php echo e(isset($currentLanguageCode) ? $currentLanguageCode : 'en'); ?>" class="ie9 no-js <?php echo e(($showHeaderAdminBar) ? 'show-admin-bar' : ''); ?>"> <![endif]-->
<!--[if !IE]><!-->
<html lang="<?php echo e(isset($currentLanguageCode) ? $currentLanguageCode : 'en'); ?>" class="<?php echo e(($showHeaderAdminBar) ? 'show-admin-bar' : ''); ?>">
<!--<![endif]-->
<head>
    <?php echo $__env->make('front/_shared/_metas', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <!-- GLOBAL PLUGINS -->
    <?php /*<link rel="stylesheet" href="/fonts/Open-Sans/font.css">*/ ?>
    <!-- GLOBAL PLUGINS -->

    <!-- OTHER PLUGINS -->
    <?php echo $__env->yieldContent('css'); ?>
    <!-- END OTHER PLUGINS -->

    <!-- BEGIN THEME LAYOUT STYLES -->
    <link href="http://fontawesome.io/assets/font-awesome/css/font-awesome.css" rel="stylesheet" type="text/css"/>
    <link href="/css/style.css" rel="stylesheet" type="text/css" media="all"/>
    <!-- END THEME LAYOUT STYLES -->

    <link rel="stylesheet"href="//codeorigin.jquery.com/ui/1.10.2/themes/smoothness/jquery-ui.css" />

    <link rel="stylesheet" href="/css/responsive.css">
    <?php if($showHeaderAdminBar): ?>
        <link rel="stylesheet" href="/admin/css/admin-bar.css">
    <?php endif; ?>

    <link rel="shortcut icon" href="<?php echo e(isset($CMSSettings['favicon']) ? $CMSSettings['favicon'] : ''); ?>"/>

    <?php echo isset($CMSSettings['google_analytics']) ? $CMSSettings['google_analytics'] : ''; ?>

    <script>
        var delUrl = "<?php echo e(asset('/').'/cart/delete/'); ?>";
        var upUrl = "<?php echo e(asset('/').'/cart/update-cart-quantity/'); ?>";
    </script>
    <?php echo $__env->yieldPushContent('style'); ?>

    <!-- BEGIN CORE PLUGINS -->
    <script src="/dist/core.min.js"></script>
    <!-- END CORE PLUGINS -->
</head>

<body class="cms-index-index cms-home">

<?php if($showHeaderAdminBar): ?>
    <?php echo $__env->make('admin/_shared/_admin-bar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php endif; ?>

<div class="wrap">
    <noscript>
        <div class="global-site-notice noscript">
            <div class="notice-inner">
                <p>
                    <strong>Dường như JavaScript bị tắt trong trình duyệt của bạn.</strong><br />
                    Bạn phải có bật Javascript trong trình duyệt của bạn để sử dụng các chức năng của trang web này.
                </p>
            </div>
        </div>
    </noscript>
    <div class="page">
        <header class="header">
            <?php echo $__env->make('front/_shared/_header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </header>
        <div class="clearfix"></div>
        <div id="maincontain" class="col1-layout">
            <div class="main">
                <div class="col-main">
                    <?php if (! empty(trim($__env->yieldContent('slideshow')))): ?>
                        <?php echo $__env->yieldContent('slideshow'); ?>
                    <?php else: ?>
                    <div class="container">
                        <div class="row">
                            <div class="col-md-10 col-md-offset-1">
                                <?php echo _breadcrumb(); ?>

                            </div>
                        </div>
                    </div>
                    <?php endif; ?>
                    <div class="container">
                        <div class="row">
                            <div class="col-md-10 col-md-offset-1">
                                <?php echo $__env->yieldContent('content'); ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <footer class="footer">
            <?php if(isset($CMSSettings['banner_bottom'])): ?>
            <div class="banner-group">
                <a><img src="<?php echo e(isset($CMSSettings['banner_bottom']) ? $CMSSettings['banner_bottom'] : ''); ?>" /></a>
            </div>
            <?php endif; ?>
            <?php echo $__env->make('front/_shared/_footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </footer>
    </div>
</div>

<!--Modals-->
<?php echo $__env->make('front/_shared/_modals', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<!--[if lt IE 9]>
<script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
<script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
<![endif]-->

<!--Google captcha-->
<?php echo $__env->make('front/_shared/_google-captcha', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<!--Google captcha-->

<!-- OTHER PLUGINS -->
<?php echo $__env->yieldContent('js'); ?>
<!-- END OTHER PLUGINS -->

<!-- BEGIN THEME LAYOUT SCRIPTS -->
<script src="/dist/app.min.js"></script>
<!-- END THEME LAYOUT SCRIPTS -->

<!-- JS INIT -->
<?php echo $__env->yieldContent('js-init'); ?>
<!-- JS INIT -->

<script>
    (function($) {

        var $nav = $('nav#mainmenu');
        var $btn = $('nav#mainmenu button');
        var $vlinks = $('nav#mainmenu .nav.navbar-nav');
        var $hlinks = $('nav#mainmenu .hidden-links');

        var numOfItems = 0;
        var totalSpace = 0;
        var breakWidths = [];

        // Get initial state
        $vlinks.children().outerWidth(function(i, w) {
            totalSpace += w;
            numOfItems += 1;
            breakWidths.push(totalSpace);
        });

        var availableSpace, numOfVisibleItems, requiredSpace;

        function check() {

            // Get instant state
            availableSpace = $vlinks.width() - 10;
            numOfVisibleItems = $vlinks.children().length;
            requiredSpace = breakWidths[numOfVisibleItems - 1];

            // There is not enought space
            if (requiredSpace > availableSpace) {
            $vlinks.children().last().prependTo($hlinks);
            numOfVisibleItems -= 1;
            check();
            // There is more than enough space
            } else if (availableSpace > breakWidths[numOfVisibleItems]) {
            $hlinks.children().first().appendTo($vlinks);
            numOfVisibleItems += 1;
            }
            // Update the button accordingly
            $btn.attr("count", numOfItems - numOfVisibleItems);
            if (numOfVisibleItems === numOfItems) {
            $btn.addClass('hidden');
            } else $btn.removeClass('hidden');
        }

        // Window listeners
        $(window).resize(function() {
            check();
        });

        $btn.on('click', function() {
            $hlinks.toggleClass('hidden');
        });

        check();

    })(jQuery);

    $('.quantity').change(function(event) {
  	    var value = $(this).val();
  	    var id = $(this).attr('pid');
  	    $.ajax({
  	      	url: upUrl + id + '/' + value,
  	      	type: 'GET',
  		 	beforeSend: function(){
  		    	$('.loading').css('display', 'block');
  		  	},
  		  	complete: function(){
  	        	location.reload()
  		   	}
  	    });
  	});

	/*Delete item*/
    $('.deteteElem').click(function(event) {
        var id = $(this).attr('id');
        $.ajax({
          	url: delUrl + id ,
          	type: 'GET',
		 	beforeSend: function(){
		    	$('.loading').css('display', 'block');
		  	},
		  	complete: function(){
	        	location.reload()
		   	}
        });
    });

    (function($) {
        var isClosed = true;
        $('.cart').click(function(){
        if(isClosed)
        {
            $(this).addClass("active");
            $(this).removeClass("hover");
            $('.cd-cart-items').slideDown('normal');
            isClosed = false;
        }
        else
        {
            $(this).removeClass("active");
            $('.cd-cart-items').slideUp('normal');
            isClosed = true;
        }
        });
    })(jQuery);

    $('.header').css({
        'background-image': "url(<?php echo e($CMSSettings['bg_header']); ?>)",
        'background-repeat': "no-repeat",
        'background-position': '0px 25%',
        'background-size': '100%'
    })
</script>

<?php echo $__env->make('front/_shared/_flash-messages', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

</body>

</html>
