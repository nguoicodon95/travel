<div class="scf-text-wrap">
    <input type="text" data-fieldtype="<?php echo e(isset($fieldItem->field_type_updated) ? $fieldItem->field_type_updated : ''); ?>" data-slug="<?php echo e(isset($fieldItem->slug) ? $fieldItem->slug : ''); ?>"
           value="<?php echo e(isset($theMeta) ? $theMeta : ''); ?>" placeholder="<?php echo e(isset($options->placeholdertext) ? $options->placeholdertext : ''); ?>" class="form-control">
</div>