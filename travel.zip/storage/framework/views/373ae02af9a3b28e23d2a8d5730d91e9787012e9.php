<?php if(isset($rules) && $rules): ?>
    <?php foreach($rules as $key => $row): ?>
        <div class="line-group and-group" data-text="" data-rel="and">
            <?php foreach($row->field_options as $keyOptions => $rowOptions): ?>
                <div class="line rule-line rule-and">
                    <select name="" class="form-control pull-left rule-a" id="">
                        <optgroup label="Basic">
                            <option value="user_type" <?php echo e((($rowOptions->rel_name == 'user_type') ? 'selected="selected"' : '')); ?>>
                                Logged in User Type
                            </option>
                        </optgroup>
                        <optgroup label="Page">
                            <option value="page_id" <?php echo e((($rowOptions->rel_name == 'page_id') ? 'selected="selected"' : '')); ?>>
                                Page
                            </option>
                            <option value="page_template" <?php echo e((($rowOptions->rel_name == 'page_template') ? 'selected="selected"' : '')); ?>>
                                Page Template
                            </option>
                        </optgroup>
                        <optgroup label="Post">
                            <option value="post_template" <?php echo e((($rowOptions->rel_name == 'post_template') ? 'selected="selected"' : '')); ?>>
                                Post Template
                            </option>
                            <option value="category_id" <?php echo e((($rowOptions->rel_name == 'category_id') ? 'selected="selected"' : '')); ?>>
                                Category
                            </option>
                            <option value="category_template" <?php echo e((($rowOptions->rel_name == 'category_template') ? 'selected="selected"' : '')); ?>>
                                Category Template
                            </option>
                            <option value="post_with_related_category_id" <?php echo e((($rowOptions->rel_name == 'post_with_related_category_id') ? 'selected="selected"' : '')); ?>>
                                Post with related category
                            </option>
                        </optgroup>
                        <optgroup label="Product">
                            <option value="product_template" <?php echo e((($rowOptions->rel_name == 'product_template') ? 'selected="selected"' : '')); ?>>
                                Product Template
                            </option>
                            <option value="product_category_id" <?php echo e((($rowOptions->rel_name == 'product_category_id') ? 'selected="selected"' : '')); ?>>
                                Product Category
                            </option>
                            <option value="product_category_template" <?php echo e((($rowOptions->rel_name == 'product_category_template') ? 'selected="selected"' : '')); ?>>
                                Product Category Template
                            </option>
                            <option value="product_with_related_product_category_id" <?php echo e((($rowOptions->rel_name == 'product_with_related_product_category_id') ? 'selected="selected"' : '')); ?>>
                                Product with related category
                            </option>
                        </optgroup>
                        <optgroup label="Other">
                            <option value="scf_user" <?php echo e((($rowOptions->rel_name == 'scf_user') ? 'selected="selected"' : '')); ?>>
                                User
                            </option>
                            <option value="model_name" <?php echo e((($rowOptions->rel_name == 'model_name') ? 'selected="selected"' : '')); ?>>
                                Model name
                            </option>
                        </optgroup>
                    </select>
                    <select name="" class="form-control pull-left rule-type" id="">
                        <option value="==" <?php echo e((($rowOptions->rel_type == '==') ? 'selected="selected"' : '')); ?>>is equal to</option>
                        <option value="!=" <?php echo e((($rowOptions->rel_type == '!=') ? 'selected="selected"' : '')); ?>>is not equal to</option>
                    </select>
                    <div class="rules-b-group mar-lef-5 pull-left">
                        <select name="" class="form-control rule-b hidden" id="" data-rel="category_id">
                            <?php echo $__env->make('admin._partials.custom-fields._categories-selectbox', ['categories' => $categories, 'childText' => 0, 'selectedNode' => $rowOptions->rel_value], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                        </select>
                        <select name="" class="form-control rule-b hidden" id=""
                                data-rel="post_with_related_category_id">
                            <?php echo $__env->make('admin._partials.custom-fields._categories-selectbox', ['categories' => $categories, 'childText' => 0, 'selectedNode' => $rowOptions->rel_value], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                        </select>
                        <select name="" class="form-control rule-b hidden" id="" data-rel="product_category_id">
                            <?php echo $__env->make('admin._partials.custom-fields._categories-selectbox', ['categories' => $productCategories, 'childText' => 0, 'selectedNode' => $rowOptions->rel_value], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                        </select>
                        <select name="" class="form-control rule-b hidden" id=""
                                data-rel="product_with_related_product_category_id">
                            <?php echo $__env->make('admin._partials.custom-fields._categories-selectbox', ['categories' => $productCategories, 'childText' => 0, 'selectedNode' => $rowOptions->rel_value], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                        </select>
                        <select name="" class="form-control rule-b hidden" id="" data-rel="user_type">
                            <?php if(isset($options['roles'])): ?> <?php foreach($options['roles'] as $option): ?>
                                <option value="<?php echo e(isset($option->id) ? $option->id : ''); ?>" <?php echo e((($rowOptions->rel_name == 'user_type' && $rowOptions->rel_value == $option->id) ? 'selected="selected"' : '')); ?>><?php echo e(isset($option->name) ? $option->name : ''); ?></option>
                            <?php endforeach; ?> <?php endif; ?>
                        </select>
                        <select name="" class="form-control rule-b hidden" id="" data-rel="page_id">
                            <?php if(isset($options['pages'])): ?> <?php foreach($options['pages'] as $option): ?>
                                <option value="<?php echo e(isset($option->id) ? $option->id : ''); ?>" <?php echo e((($rowOptions->rel_name == 'page_id' && $rowOptions->rel_value == $option->id) ? 'selected="selected"' : '')); ?>><?php echo e(isset($option->global_title) ? $option->global_title : ''); ?></option>
                            <?php endforeach; ?> <?php endif; ?>
                        </select>
                        <select name="" class="form-control rule-b hidden" id="" data-rel="page_template">
                            <?php if(isset($options['page_templates'])): ?> <?php foreach($options['page_templates'] as $option): ?>
                                <option value="<?php echo e(isset($option) ? $option : ''); ?>" <?php echo e((($rowOptions->rel_name == 'page_template' && $rowOptions->rel_value == $option) ? 'selected="selected"' : '')); ?>><?php echo e(isset($option) ? $option : ''); ?></option>
                            <?php endforeach; ?> <?php endif; ?>
                        </select>
                        <select name="" class="form-control rule-b hidden" id="" data-rel="post_template">
                            <?php if(isset($options['post_templates'])): ?> <?php foreach($options['post_templates'] as $option): ?>
                                <option value="<?php echo e(isset($option) ? $option : ''); ?>" <?php echo e((($rowOptions->rel_name == 'post_template' && $rowOptions->rel_value == $option) ? 'selected="selected"' : '')); ?>><?php echo e(isset($option) ? $option : ''); ?></option>
                            <?php endforeach; ?> <?php endif; ?>
                        </select>
                        <select name="" class="form-control rule-b hidden" id="" data-rel="product_template">
                            <?php if(isset($options['product_templates'])): ?> <?php foreach($options['product_templates'] as $option): ?>
                                <option value="<?php echo e(isset($option) ? $option : ''); ?>" <?php echo e((($rowOptions->rel_name == 'product_template' && $rowOptions->rel_value == $option) ? 'selected="selected"' : '')); ?>><?php echo e(isset($option) ? $option : ''); ?></option>
                            <?php endforeach; ?> <?php endif; ?>
                        </select>
                        <select name="" class="form-control rule-b hidden" id="" data-rel="category_template">
                            <?php if(isset($options['category_templates'])): ?> <?php foreach($options['category_templates'] as $option): ?>
                                <option value="<?php echo e(isset($option) ? $option : ''); ?>" <?php echo e((($rowOptions->rel_name == 'category_template' && $rowOptions->rel_value == $option) ? 'selected="selected"' : '')); ?>><?php echo e(isset($option) ? $option : ''); ?></option>
                            <?php endforeach; ?> <?php endif; ?>
                        </select>
                        <select name="" class="form-control rule-b hidden" id="" data-rel="product_category_template">
                            <?php if(isset($options['product_category_templates'])): ?> <?php foreach($options['product_category_templates'] as $option): ?>
                                <option value="<?php echo e(isset($option) ? $option : ''); ?>" <?php echo e((($rowOptions->rel_name == 'product_category_template' && $rowOptions->rel_value == $option) ? 'selected="selected"' : '')); ?>><?php echo e(isset($option) ? $option : ''); ?></option>
                            <?php endforeach; ?> <?php endif; ?>
                        </select>
                        <select name="" class="form-control rule-b hidden" id="" data-rel="scf_user">
                            <?php if(isset($options['users'])): ?> <?php foreach($options['users'] as $option): ?>
                                <option value="<?php echo e(isset($option->id) ? $option->id : ''); ?>" <?php echo e((($rowOptions->rel_name == 'scf_user' && $rowOptions->rel_value == $option->id) ? 'selected="selected"' : '')); ?>><?php echo e(isset($option->username) ? $option->username : ''); ?></option>
                            <?php endforeach; ?> <?php endif; ?>
                        </select>
                        <select name="" class="form-control rule-b" id="" data-rel="model_name">
                            <?php if(isset($options['models'])): ?> <?php foreach($options['models'] as $option): ?>
                                <option value="<?php echo e(isset($option) ? $option : ''); ?>" <?php echo e((($rowOptions->rel_name == 'model_name' && $rowOptions->rel_value == $option) ? 'selected="selected"' : '')); ?>><?php echo e(isset($option) ? $option : ''); ?></option>
                            <?php endforeach; ?> <?php endif; ?>
                        </select>
                    </div>
                    <a class="location-add-rule-and location-add-rule btn btn-primary pull-left" href="#">and</a>
                    <a href="#" title="" class="remove-rule-line">-</a>
                    <div class="clearfix"></div>
                </div>
            <?php endforeach; ?>
        </div>
    <?php endforeach; ?>
<?php else: ?>
    <div class="line-group and-group" data-text="" data-rel="and">
        <div class="line rule-line rule-and">
            <select name="" class="form-control pull-left rule-a" id="">
                <optgroup label="Basic">
                    <option value="user_type">
                        Logged in User Type
                    </option>
                </optgroup>
                <optgroup label="Page">
                    <option value="page_id">
                        Page
                    </option>
                    <option value="page_template">
                        Page Template
                    </option>
                </optgroup>
                <optgroup label="Post">
                    <option value="post_template">
                        Post Template
                    </option>
                    <option value="category_id">
                        Category
                    </option>
                    <option value="category_template">
                        Category Template
                    </option>
                    <option value="post_with_related_category_id">
                        Post with related category
                    </option>
                </optgroup>
                <optgroup label="Product">
                    <option value="product_template">
                        Product Template
                    </option>
                    <option value="product_category_id">
                        Product Category
                    </option>
                    <option value="product_category_template">
                        Product Category Template
                    </option>
                    <option value="product_with_related_product_category_id">
                        Product with related category
                    </option>
                </optgroup>
                <optgroup label="Other">
                    <option value="scf_user">
                        User
                    </option>
                    <option value="model_name">
                        Model name
                    </option>
                </optgroup>
            </select>
            <select name="" class="form-control pull-left rule-type" id="">
                <option value="==">is equal to</option>
                <option value="!=">is not equal to</option>
            </select>
            <div class="rules-b-group mar-lef-5 pull-left">
                <select name="" class="form-control rule-b hidden" id="" data-rel="category_id">
                    <?php echo $__env->make('admin._partials.custom-fields._categories-selectbox', ['categories' => $categories, 'childText' => 0, 'selectedNode' => 0], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                </select>
                <select name="" class="form-control rule-b hidden" id=""
                        data-rel="post_with_related_category_id">
                    <?php echo $__env->make('admin._partials.custom-fields._categories-selectbox', ['categories' => $categories, 'childText' => 0, 'selectedNode' => 0], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                </select>
                <select name="" class="form-control rule-b hidden" id="" data-rel="product_category_id">
                    <?php echo $__env->make('admin._partials.custom-fields._categories-selectbox', ['categories' => $productCategories, 'childText' => 0, 'selectedNode' => 0], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                </select>
                <select name="" class="form-control rule-b hidden" id=""
                        data-rel="product_with_related_product_category_id">
                    <?php echo $__env->make('admin._partials.custom-fields._categories-selectbox', ['categories' => $productCategories, 'childText' => 0, 'selectedNode' => 0], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                </select>
                <select name="" class="form-control rule-b hidden" id="" data-rel="user_type">
                    <?php if(isset($options['roles'])): ?> <?php foreach($options['roles'] as $option): ?>
                        <option value="<?php echo e(isset($option->id) ? $option->id : ''); ?>"><?php echo e(isset($option->name) ? $option->name : ''); ?></option>
                    <?php endforeach; ?> <?php endif; ?>
                </select>
                <select name="" class="form-control rule-b hidden" id="" data-rel="page_id">
                    <?php if(isset($options['pages'])): ?> <?php foreach($options['pages'] as $option): ?>
                        <option value="<?php echo e(isset($option->id) ? $option->id : ''); ?>"><?php echo e(isset($option->global_title) ? $option->global_title : ''); ?></option>
                    <?php endforeach; ?> <?php endif; ?>
                </select>
                <select name="" class="form-control rule-b hidden" id="" data-rel="page_template">
                    <?php if(isset($options['page_templates'])): ?> <?php foreach($options['page_templates'] as $option): ?>
                        <option value="<?php echo e(isset($option) ? $option : ''); ?>"><?php echo e(isset($option) ? $option : ''); ?></option>
                    <?php endforeach; ?> <?php endif; ?>
                </select>
                <select name="" class="form-control rule-b hidden" id="" data-rel="post_template">
                    <?php if(isset($options['post_templates'])): ?> <?php foreach($options['post_templates'] as $option): ?>
                        <option value="<?php echo e(isset($option) ? $option : ''); ?>"><?php echo e(isset($option) ? $option : ''); ?></option>
                    <?php endforeach; ?> <?php endif; ?>
                </select>
                <select name="" class="form-control rule-b hidden" id="" data-rel="product_template">
                    <?php if(isset($options['product_templates'])): ?> <?php foreach($options['product_templates'] as $option): ?>
                        <option value="<?php echo e(isset($option) ? $option : ''); ?>"><?php echo e(isset($option) ? $option : ''); ?></option>
                    <?php endforeach; ?> <?php endif; ?>
                </select>
                <select name="" class="form-control rule-b hidden" id="" data-rel="category_template">
                    <?php if(isset($options['category_templates'])): ?> <?php foreach($options['category_templates'] as $option): ?>
                        <option value="<?php echo e(isset($option) ? $option : ''); ?>"><?php echo e(isset($option) ? $option : ''); ?></option>
                    <?php endforeach; ?> <?php endif; ?>
                </select>
                <select name="" class="form-control rule-b hidden" id="" data-rel="product_category_template">
                    <?php if(isset($options['product_category_templates'])): ?> <?php foreach($options['product_category_templates'] as $option): ?>
                        <option value="<?php echo e(isset($option) ? $option : ''); ?>"><?php echo e(isset($option) ? $option : ''); ?></option>
                    <?php endforeach; ?> <?php endif; ?>
                </select>
                <select name="" class="form-control rule-b hidden" id="" data-rel="scf_user">
                    <?php if(isset($options['users'])): ?> <?php foreach($options['users'] as $option): ?>
                        <option value="<?php echo e(isset($option->id) ? $option->id : ''); ?>"><?php echo e(isset($option->username) ? $option->username : ''); ?></option>
                    <?php endforeach; ?> <?php endif; ?>
                </select>
                <select name="" class="form-control rule-b" id="" data-rel="model_name">
                    <?php if(isset($options['models'])): ?> <?php foreach($options['models'] as $option): ?>
                        <option value="<?php echo e(isset($option) ? $option : ''); ?>"><?php echo e(isset($option) ? $option : ''); ?></option>
                    <?php endforeach; ?> <?php endif; ?>
                </select>
            </div>
            <a class="location-add-rule-and location-add-rule btn btn-primary pull-left" href="#">and</a>
            <a href="#" title="" class="remove-rule-line">-</a>
            <div class="clearfix"></div>
        </div>
    </div>
<?php endif; ?>