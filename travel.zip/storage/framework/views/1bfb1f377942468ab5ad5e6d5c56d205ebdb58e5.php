<?php
$imgSrc = $theMeta;
if (!trim((string)$imgSrc)) {
    $imgSrc = '/admin/images/no-image.png';
}
?>
<div class="meta-box normal-box" data-slug="<?php echo e(isset($fieldItem->slug) ? $fieldItem->slug : ''); ?>">
    <p>
        <label class="sbold"><?php echo e(isset($fieldItem->title) ? $fieldItem->title : ''); ?></label><br>
        <span class="font-size-13"><?php echo e(isset($fieldItem->instructions) ? $fieldItem->instructions : ''); ?></span>
    </p>
    <div class="scf-image-wrap">
        <div class="select-media-box">
            <a title="" class="btn blue show-add-media-popup">Choose image</a>
            <div class="clearfix"></div>
            <a title="" class="show-add-media-popup">
                <img src="<?php echo e(isset($imgSrc) ? $imgSrc : ''); ?>" alt="" class="img-responsive">
            </a>
            <input type="hidden" data-slug="<?php echo e(isset($fieldItem->slug) ? $fieldItem->slug : ''); ?>" data-fieldtype="<?php echo e(isset($fieldItem->field_type) ? $fieldItem->field_type : ''); ?>" value="<?php echo e(isset($theMeta) ? $theMeta : ''); ?>" class="input-file">
            <a href="#" title="" class="remove-image"><span>&nbsp;</span></a>
        </div>
    </div>
</div>
