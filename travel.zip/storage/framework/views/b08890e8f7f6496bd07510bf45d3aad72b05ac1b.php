<h2><?php echo e(isset($catalog['root']) ? $catalog['root'] : ''); ?></h2>
<div class="panel-group panel panel-default" id="accordion">
  <?php if(!empty($catalog['child_catalog'])): ?>
    <?php foreach($catalog['child_catalog'] as $key => $catalog): ?>
      <div class="panel">
          <div class="panel-heading">
            <h4 class="panel-title">
              <a href="<?php echo e(_getCategoryLinkWithParentSlugs($catalog->id)); ?>">
                <?php echo e($catalog->title); ?>

              </a>
              <?php if($catalog->child()->count() > 0): ?>
              <span style="cursor: pointer" class="accordion-toggle pull-right" data-toggle="collapse" data-parent="#accordion" href="#collapseOne"> -- </span>
              <?php endif; ?>
            </h4>
          </div>
          <div id="collapseOne" class="panel-collapse collapse <?php echo e(($object->parent_id != 0) && $object->parent->slug == $catalog->slug ? 'in' : ''); ?>">
              <?php if($catalog->child()->count() > 0): ?>
              <ul class="list-group">
                <?php foreach( $catalog->child as $child_of_child ): ?>
                  <li class="list-group-item <?php echo e($catalog_current == $child_of_child->slug ? 'active' : ''); ?>"><a href="<?php echo e(_getCategoryLinkWithParentSlugs($child_of_child->id)); ?>">- <?php echo e($child_of_child->title); ?></a></li>
                <?php endforeach; ?>
              </ul>
              <?php endif; ?>
          </div>
      </div>
    <?php endforeach; ?>
  <?php endif; ?>
 </div>
