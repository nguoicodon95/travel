<div class="line" data-option="defaultvaluetextarea">
    <div class="col-xs-3">
        <h5>Default Value</h5>
        <p>Appears when creating a new post</p>
    </div>
    <div class="col-xs-9">
        <h5>Default Value</h5>
        <textarea class="form-control" rows="3"><?php echo e(isset($options->defaultvaluetextarea) ? $options->defaultvaluetextarea : ''); ?></textarea>
    </div>
    <div class="clearfix"></div>
</div>