<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>Đơn đặt hàng mới</title>
  </head>
  <body>
    <p>Xin chào Admin <a href="http://dieuhoadaikin.com">dieuhoadaikin.com</a> !</p>
  	<p><strong><?php echo e(isset($data['transaction']['object']->name) ? $data['transaction']['object']->name : ''); ?></strong> đã gửi 1 yêu cầu đặt hàng đến hệ thống <?php echo e(isset($data['transaction']['object']->created_at) ? $data['transaction']['object']->created_at : ''); ?></p>

  	<a href="<?php echo e(asset($adminCpAccess . '/orders/detail/' . $data['transaction']['object']->id)); ?>">Chi tiết đơn hàng #<?php echo e($data['transaction']['object']->id); ?></a>

  	<p>Thông tin liên hệ</p>
  	<table>
  		<tr>
  			<td>Họ tên:</td>
  			<td><?php echo e($data['transaction']['object']->name); ?></td>
  		</tr>
  		<tr>
  			<td>Email:</td>
  			<td><?php echo e($data['transaction']['object']->email); ?></td>
  		</tr>
  		<tr>
  			<td>Số ĐT:</td>
  			<td><?php echo e($data['transaction']['object']->phone); ?></td>
  		</tr>
  		<tr>
  			<td>Địa chỉ:</td>
  			<td><?php echo e($data['transaction']['object']->address); ?></td>
  		</tr>
  	</table>

  	<h5>Thông tin đơn hàng của <?php echo e($data['transaction']['object']->name); ?></h5>
  	<div class="row col-md-12 cart-item">
  	    <div class="table-responsive cart_info">
  	        <table style="boder: 1px solid #ccc; text-align: center;">
  	            <thead>
  	                <tr style="background: #1F79A7; color: #FFF;">
  	                    <th>Mã Sản phẩm</th>
  	                    <th class="image" width="80">Sản phẩm</th>
  	                    <th width="170"></th>
  	                    <th class="">Giá tiền</th>
  	                    <th class="">Số lượng</th>
  	                    <th class="price">Tổng tiền</th>
  	                </tr>
  	            </thead>
        				<?php foreach($data['orders'] as $item): ?>
                  <?php
                    $product = \App\Models\Product::getById($item->product_id);
                  ?>
  	                <tbody>
  	                    <tr>
                            <td>
                              <?php echo e($product->sku); ?>

                            </td>
  	                        <td>
  	                        	<img src="<?php echo e(asset($product->thumbnail)); ?>" alt="<?php echo e($product->title); ?>" width="150"/>
  	                        </td>
  	                        <td>
  	                            <h4><a href="<?php echo e(_getProductLink($product->slug)); ?>"> <?php echo e($product->title); ?> </a></h4>
  	                        </td>
  	                        <td>
  	                            <p><?php echo e(_formatPrice($product->price)); ?></p>
  	                        </td>
  	                        <td>
  	                            <div>
                                  <?php echo e($item->qty); ?>

  	                            </div>
  	                        </td>
  	                        <td>
  	                            <p><?php echo e(_formatPrice($product->price*$item->qty)); ?></p>
  	                        </td>
  	                    </tr>
    					<?php endforeach; ?>
  						<tr style="background: #1F79A7; color: #FFF;">
  							<td colspan="6">Tổng cộng</td>
  							<td><?php echo e(_formatPrice($data['transaction']['object']->amount)); ?></td>
  						</tr>
  	                </tbody>
  	            </table>
  	        </div>
  	    </div>
  	</div>
  </body>
</html>
