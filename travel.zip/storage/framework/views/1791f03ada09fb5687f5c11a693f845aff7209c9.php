<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>Thông tin booking tour</title>
  </head>
  <body>
    <p>Xin chào Admin <a href=""></a> !</p>
  	<p><strong><?php echo e(isset($data['booking']['object']->fullname) ? $data['booking']['object']->fullname : ''); ?></strong> đã đăng ký đặt chỗ <?php echo e(isset($data['booking']['object']->created_at) ? $data['booking']['object']->created_at : ''); ?></p>

  	<a href="">Chi tiết booking #<?php echo e($data['booking']['object']->id); ?></a>

  	<h2>Thông tin liên hệ</h2>
  	<table>
  		<tr>
  			<td>Họ tên:</td>
  			<td><?php echo e($data['booking']['object']->fullname); ?></td>
  		</tr>
  		<tr>
  			<td>Email:</td>
  			<td><?php echo e($data['booking']['object']->email); ?></td>
  		</tr>
  		<tr>
  			<td>Số ĐT:</td>
  			<td><?php echo e($data['booking']['object']->phone); ?></td>
  		</tr>
  		<tr>
  			<td>Địa chỉ:</td>
  			<td><?php echo e($data['booking']['object']->address); ?></td>
  		</tr>
  	</table>
    <?php if($data['booking']['object']->post_id != NULL): ?>
    <p>
      Chuyến tour <?php echo e(isset($data['booking']['object']->fullname) ? $data['booking']['object']->fullname : ''); ?> quan tâm: <strong><a href="<?php echo e(_getPostLink( $data['booking']['object']->post->slug)); ?>"><?php echo e($data['booking']['object']->post->title); ?></a></strong>
    </p>
    <?php endif; ?>
  </body>
</html>
