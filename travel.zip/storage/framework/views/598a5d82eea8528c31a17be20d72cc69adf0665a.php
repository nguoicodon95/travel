<?php $__env->startSection('css'); ?>
  <style>
    .box-title .lb-name {
      float: left;
      font-size: 20px;
      font-weight: 600;
      font-style: normal;
      color: #333;
      text-transform: uppercase;
      margin: 10px 0 0;
    }
    .box-title .lb-desc {
      display: block;
      font-size: 14px;
      color: #666;
      clear: both;
    }
    .box-contact {
      line-height: 22px;
    }
    .contact-line {
      border-bottom: 1px dotted #d2d2d2;
      margin: 10px 0;
    }
    .box-contact .bc-yellow {
      background: #f9c200;
    }
    .box-contact .bc-green {
      background: #84bb39;
    }
    .box-contact .bc-box {
      padding: 15px 0;
      text-align: center;
      color: #fff;
      font-size: 22px;
      font-weight: 600;
      margin: 15px 0 0;
      line-height: 30px;
    }
    .bc-box a {
      color: #fff;
    }
    .box-contact label .fa {
      margin-right: 7px;
      font-size: 16px;
    }
  </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js-init'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="map">
  <?php echo isset($object->content) ? $object->content : ''; ?>

</div>
<div class="section">
    <div class="container">
        <div class="row">
          <div class="col-md-6">
            <div class="box">
                  <div class="box-title">
                    <h1 class="lb-name">Entrer en contact</h1>
                      <span class="lb-desc">ACACIA VOYAGE</span>
                  </div>
                  <div class="box-content">
                    <div class="box-contact">
                        <div class="contact-line"></div>
                          <div class="row">
                              <div class="col-sm-3 reset-padding-right">
                                  <label><i class="fa fa-home"></i>Adresse:</label>
                              </div><!-- col -->
                              <div class="col-sm-9">
                                  <p><?php echo e(isset($CMSSettings['address']) ? $CMSSettings['address'] : ''); ?></p>
                              </div><!-- col -->
                          </div><!-- row -->
                          <div class="contact-line"></div>
                          <div class="row">
                              <div class="col-sm-3 reset-padding-right">
                                  <label><i class="fa fa-envelope"></i>Mail:</label>
                              </div><!-- col -->
                              <div class="col-sm-9">
                                  <p><a href="mailto:<?php echo e(isset($CMSSettings['email']) ? $CMSSettings['email'] : ''); ?>"><?php echo e(isset($CMSSettings['email']) ? $CMSSettings['email'] : ''); ?></a></p>
                              </div><!-- col -->
                          </div><!-- row -->
                          <div class="contact-line"></div>
                          <div class="row">
                              <div class="col-sm-3 reset-padding-right">
                                  <label><i class="fa fa-phone"></i>Phone:</label>
                              </div><!-- col -->
                              <div class="col-sm-9">
                                  <p>Tel: <?php echo e(isset($CMSSettings['phone']) ? $CMSSettings['phone'] : ''); ?></p>
                              </div><!-- col -->
                          </div><!-- row -->
                          <div class="row">
                            <div class="col-md-12 col-sm-6">
                                  <div class="bc-box bc-yellow">
                                      NUMÉRO URGENT
                                      <br>
                                      <?php echo e(isset($CMSSettings['phone']) ? $CMSSettings['phone'] : ''); ?>

                                  </div>
                              </div><!-- col -->
                              <div class="col-md-12 col-sm-6">
                                  <div class="bc-box bc-green">
                                      E-MAIL
                                      <br>
                                      <a href="mailto:<?php echo e(isset($CMSSettings['email']) ? $CMSSettings['email'] : ''); ?>"><?php echo e(isset($CMSSettings['email']) ? $CMSSettings['email'] : ''); ?></a>
                                  </div>
                              </div><!-- col -->
                          </div><!-- row -->
                      </div><!-- box-contact -->
                  </div><!-- box-content -->
              </div>
          </div>
          <div class="col-md-6">
            <?php echo $__env->make('front._modules._contact-us', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
          </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('front._master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>