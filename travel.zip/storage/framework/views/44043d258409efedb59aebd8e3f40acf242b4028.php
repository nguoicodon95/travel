<!DOCTYPE html>
<!--[if IE 8]>
<html lang="<?php echo e(isset($currentLanguageCode) ? $currentLanguageCode : 'en'); ?>" class="ie8 no-js <?php echo e(($showHeaderAdminBar) ? 'show-admin-bar' : ''); ?>"> <![endif]-->
<!--[if IE 9]>
<html lang="<?php echo e(isset($currentLanguageCode) ? $currentLanguageCode : 'en'); ?>" class="ie9 no-js <?php echo e(($showHeaderAdminBar) ? 'show-admin-bar' : ''); ?>"> <![endif]-->
<!--[if !IE]><!-->
<html lang="<?php echo e(isset($currentLanguageCode) ? $currentLanguageCode : 'en'); ?>" class="<?php echo e(($showHeaderAdminBar) ? 'show-admin-bar' : ''); ?>">
<!--<![endif]-->
    <head>
        <?php echo $__env->make('front/_shared/_metas', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <!-- GLOBAL PLUGINS -->
        <?php /*<link rel="stylesheet" href="/fonts/Open-Sans/font.css">*/ ?>
        <!-- GLOBAL PLUGINS -->
        <!-- OTHER PLUGINS -->
        <?php echo $__env->yieldContent('css'); ?>
        <!-- END OTHER PLUGINS -->
        <!-- BEGIN THEME LAYOUT STYLES -->
        <link href="/third_party/slides/responsiveslides.css" rel="stylesheet" type="text/css" media="all"/>
        <link href="/css/style.css" rel="stylesheet" type="text/css" media="all"/>
        <!-- END THEME LAYOUT STYLES -->
        <!-- NOSCRIPT -->
        <noscript>
            <link href="/css/noscript.css" rel="stylesheet" type="text/css" media="all"/>
        </noscript>
        <!-- END NOSCRIPT -->
        <link rel="stylesheet" href="/css/responsive.css">
        <?php if($showHeaderAdminBar): ?>
        <link rel="stylesheet" href="/admin/css/admin-bar.css">
        <?php endif; ?>
        <link rel="shortcut icon" href="<?php echo e(isset($CMSSettings['favicon']) ? $CMSSettings['favicon'] : ''); ?>"/>
        <?php echo isset($CMSSettings['google_analytics']) ? $CMSSettings['google_analytics'] : ''; ?>

        <?php echo $__env->yieldPushContent('style'); ?>
        <!-- BEGIN CORE PLUGINS -->
        <script src="/dist/core.min.js"></script>
        <!-- END CORE PLUGINS -->
        <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
        <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
        <![endif]-->
        <!-- OTHER PLUGINS -->
        <?php echo $__env->yieldContent('js'); ?>
        <!-- END OTHER PLUGINS -->
        <!-- BEGIN THEME LAYOUT SCRIPTS -->
        <script src="/dist/app.min.js"></script>
        <!-- END THEME LAYOUT SCRIPTS -->
        <script src="/third_party/slides/responsiveslides.min.js"></script>
        <!-- JS INIT -->
        <?php echo $__env->yieldContent('js-init'); ?>
        <!-- END JS INIT -->
        <script>
            $(function () {
                $(".rslides").responsiveSlides({
                    auto: true,
                    pager: true,
                    nav: true,
                    speed: 700,
                    timeout: 7000,
                    namespace: "centered-btns"
                });
            });
            $(function () {
                var width = $(window).width();
                // if(width >= 1200) {
                    $(".dropdown").hover(
                        function() {
                            $('.dropdown-menu', this).not('.in .dropdown-menu').stop(true,true).slideDown("400");
                            $(this).toggleClass('open');
                        },
                        function() {
                            $('.dropdown-menu', this).not('.in .dropdown-menu').stop(true,true).slideUp("400");
                            $(this).toggleClass('open');
                        }
                    );
                // }
            });
        </script>
    </head>
    <body><?php if($showHeaderAdminBar): ?> <?php echo $__env->make('admin/_shared/_admin-bar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?> <?php endif; ?>
        <div class="wrap">
            <noscript>
            <div class="global-site-notice noscript">
                <div class="notice-inner">
                    <p>
                        <strong>Dường như JavaScript bị tắt trong trình duyệt của bạn.</strong><br />
                        Bạn phải có bật Javascript trong trình duyệt của bạn để sử dụng các chức năng của trang web này.
                    </p>
                </div>
            </div>
            </noscript>
            <div class="page">
                <header class="header">
                    <?php echo $__env->make('front/_shared/_header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                </header>
                <?php if(isset($show_slide) && $show_slide == true): ?>
                <div class="rslides_container">
                    <ul class="rslides" id="slider-gallery">
                        <?php if(!empty($slides_default)): ?>
                            <?php foreach($slides_default as $row): ?>
                            <li>
                                <a href="#">
                                    <img src="<?php echo e($row['image']); ?>" alt="<?php echo e($row['title']); ?>" />
                                </a>
                                <div class="scaption">
                                    <div class="scaption-inner">
                                        <div class="container">
                                            <div class="scaption-item">
                                                <h3><a href="<?php echo e($row['link']); ?>"><?php echo e($row['caption']); ?></a></h3>
                                            </div><!-- scaption-item -->
                                        </div><!-- container -->
                                    </div><!-- scaption-inner -->
                                </div>
                            </li>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </ul>
                </div>
                <?php endif; ?>
                <div class="clearfix"></div>
                <div class="main">
                    <div class="col-main">
                        <?php echo $__env->yieldContent('content'); ?>
                    </div>
                </div>
                <footer class="footer">
                    <?php echo $__env->make('front/_shared/_footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                </footer>
            </div>
        </div>
        <!--Modals-->
        <?php echo $__env->make('front/_shared/_modals', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <!--Google captcha-->
        <?php echo $__env->make('front/_shared/_google-captcha', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <!--Google captcha-->
        <?php echo $__env->make('front/_shared/_flash-messages', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </body>
</html>
