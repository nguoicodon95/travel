<?php if(isset($menuNodes) && !empty($menuNodes)): ?>
    <ol class="dd-list">
        <?php foreach($menuNodes as $key => $row): ?>
            <?php
            $dataTitle = $row->title;
            if (!$dataTitle || $dataTitle == '' || trim($dataTitle, '') == '') {
                switch ($row->type) {
                    case 'category':{
                        $category = $row->category;
                        if ($category) {
                            $dataTitle = $category->title;
                        }
                    }
                        break;
                    case 'product-category':{
                        $category = $row->productCategory;
                        if ($category) {
                            $dataTitle = $category->title;
                        }
                    }
                        break;
                    case 'page':{
                        $post = $row->page;
                        if ($post) {
                            $dataTitle = $post->title;
                        }
                    }
                        break;
                    default:{
                        $post = $row->page;
                        if ($post) {
                            $dataTitle = $post->title;
                        }
                    }
                        break;
                }
            }
            $dataTitle = htmlentities($dataTitle);
            ?>
            <li class="dd-item dd3-item <?php echo e((($row->related_id > 0 && $row->related_id != '' && $row->related_id != null) ? 'post-item' : '')); ?>"
                data-type="<?php echo e(isset($row->type) ? $row->type : ''); ?>"
                data-relatedid="<?php echo e(isset($row->related_id) ? $row->related_id : ''); ?>"
                data-title="<?php echo e(isset($row->title) ? $row->title : ''); ?>"
                data-class="<?php echo e(isset($row->css_class) ? $row->css_class : ''); ?>"
                data-id="<?php echo e(isset($row->id) ? $row->id : ''); ?>"
                data-customurl="<?php echo e(isset($row->url) ? $row->url : ''); ?>"
                data-iconfont="<?php echo e(isset($row->icon_font) ? $row->icon_font : ''); ?>">
                <div class="dd-handle dd3-handle"></div>
                <div class="dd3-content">
                    <span class="text pull-left" data-update="title"><?php echo e($dataTitle); ?></span>
                    <span class="text pull-right"><?php echo e(isset($row->type) ? $row->type : ''); ?></span>
                    <a href="#" title="" class="show-item-details">
                        <i class="fa fa-angle-down"></i>
                    </a>
                    <div class="clearfix"></div>
                </div>
                <div class="item-details">
                    <label class="pad-bot-5">
                        <span class="text pad-top-5 dis-inline-block" data-update="title">Title</span>
                        <input type="text" name="title" value="<?php echo e(isset($row->title) ? $row->title : ''); ?>" data-old="">
                    </label>
                    <label class="pad-bot-5 dis-inline-block">
                        <span class="text pad-top-5" data-update="customurl">Url</span>
                        <input type="text" name="customurl" value="<?php echo e(isset($row->url) ? $row->url : ''); ?>" data-old="">
                    </label>
                    <label class="pad-bot-5 dis-inline-block">
                        <span class="text pad-top-5" data-update="iconfont">Icon - font</span>
                        <input type="text" name="iconfont" value="<?php echo e(isset($row->icon_font) ? $row->icon_font : ''); ?>" data-old="">
                    </label>
                    <label class="pad-bot-10">
                        <span class="text pad-top-5 dis-inline-block">CSS class</span>
                        <input type="text" name="class" value="<?php echo e(isset($row->css_class) ? $row->css_class : ''); ?>" data-old="">
                    </label>
                    <div class="text-right">
                        <a href="#" title="" class="btn red btn-remove btn-sm">Remove</a>
                        <a href="#" title="" class="btn blue btn-cancel btn-sm">Cancel</a>
                    </div>
                </div>
                <div class="clearfix"></div>
                <?php echo $__env->make('admin._partials.menu._nestable-menu-src', ['menuNodes' => $row->child()->orderBy('position', 'ASC')->get()], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            </li>
        <?php endforeach; ?>
    </ol>
<?php endif; ?>