<div class="meta-box normal-box" data-slug="<?php echo e($fieldItem->slug); ?>">
    <p>
        <label class="sbold"><?php echo e(isset($fieldItem->title) ? $fieldItem->title : ''); ?></label><br>
        <span class="font-size-13"><?php echo e(isset($fieldItem->instructions) ? $fieldItem->instructions : ''); ?></span>
    </p>
    <div class="scf-text-wrap">
        <input type="text" data-fieldtype="<?php echo e(isset($fieldItem->field_type) ? $fieldItem->field_type : ''); ?>" data-slug="<?php echo e(isset($fieldItem->slug) ? $fieldItem->slug : ''); ?>"
               value="<?php echo e(isset($theMeta) ? $theMeta : ''); ?>" placeholder="<?php echo e(isset($options->placeholdertext) ? $options->placeholdertext : ''); ?>" class="form-control">
    </div>
</div>