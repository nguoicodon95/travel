<?php $__env->startSection('css'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('slideshow'); ?>
<div class="slideshow">
    <ul id="gallery">
        <?php if(isset($slideshow) && !empty($slideshow)): ?>
            <?php foreach($slideshow as $s): ?>
        <li>
            <a href="<?php echo e($s['link']); ?>">
                <img src="<?php echo e($s['image']); ?>">
            </a>
        </li>
            <?php endforeach; ?>
        <?php endif; ?>
    </ul>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <!--div class="std">
        <div class="maintext">
            <h1>&nbsp;</h1>
        </div>
    </div-->
    <div class="products_grid p_block_home_top">
        <h2 class="group_title"><span>Sản Phẩm mới nhất</span></h2>
        <!--<div class="banner-group"><img src=""></div>-->
        <div class="prbx">
        <?php if(isset($new_product) && !empty($new_product)): ?>
            <?php $__empty_1 = true; foreach($new_product as $p): $__empty_1 = false; ?>
                <?php $row = $p->productContent; ?>
                <div class="col-md-3 grid">
                    <div class="item">
                        <div class="thumb">
                            <a class="product-image" href="<?php echo e(_getProductLink($row->slug)); ?>" title="<?php echo e(isset($row->title) ? $row->title : ''); ?>">
                                <img class="product-img" src="<?php echo e(isset($row->thumbnail) ? $row->thumbnail : ''); ?>" alt="<?php echo e(isset($row->title) ? $row->title : ''); ?>" />
                            </a>
                        </div>
                        <h3>
                            <a href="<?php echo e(_getProductLink($row->slug)); ?>" title="<?php echo e($row->title); ?>"><?php echo e($row->title); ?></a>
                        </h3>
                        <div class="price-box">
                            <span class="regular-price">
                                <?php if($row->old_price != 0): ?>
                                <span class="old-price"><s><?php echo e(_formatPrice($row->old_price)); ?></s></span>
                                <?php endif; ?>
                                <span class="price"><?php echo e(_formatPrice($row->price)); ?></span>
                            </span>
                        </div>
                        <div align="left" class="bgr">
                            <a class="addcart btn btn-danger btn-sm" href="<?php echo e(_getAddToCartLink($row->id)); ?>">Đặt hàng</a>
                            <a class="detail btn btn-info btn-sm" href="<?php echo e(_getProductLink($row->slug)); ?>">Xem chi tiết</a>
                        </div>
                    </div>
                </div>
            <?php endforeach; if ($__empty_1): ?>
                <p>Hiện tại chưa có sản phẩm nào</p>
            <?php endif; ?>
        <?php endif; ?>
            <div class="clearfix"></div>
        </div>
    </div>


    <!--div class="banner-group">
        <p>
            <a href="" target="_blank">
                <img src="/images/libraries/banner.png" alt="" />
            </a>
        </p>
    </div-->

    <?php if(isset($groups) && !empty($groups)): ?>
        <?php foreach($groups as $key => $group): ?>
        <div class="products_grid p_block_home">
            <h2 class="group_title">
                <a href="<?php echo e(_getProductCategoryLink($group['slug'])); ?>"><span><?php echo e($key); ?></span></a>
            </h2>
            <?php if(!empty($group)): ?>
                <?php foreach($group as $p): ?>
                    <?php if(is_array($p)): ?>
                    <div class="col-md-3 grid">
                        <div class="item">
                            <div class="thumb">
                                <a class="product-image" href="<?php echo e(_getProductLink($p['slug'])); ?>" title="<?php echo e($p['title']); ?>">
                                    <img class="product-img" src="<?php echo e($p['thumbnail']); ?>" alt="<?php echo e($p['title']); ?>" title="<?php echo e($p['title']); ?>"/>
                                </a>
                            </div>
                            <h3>
                                <a href="<?php echo e(_getProductLink($p['slug'])); ?>" title="<?php echo e($p['title']); ?>"><?php echo e($p['title']); ?></a>
                            </h3>
                            <!-- <p class="sku">Mã SP: <?php /* $p['sku'] */ ?></p> -->

                            <div class="price-box">
                                <span class="regular-price">
                                    <?php if($p['old_price'] != 0): ?>
                                    <span class="old-price"><s><?php echo e(_formatPrice($p['old_price'])); ?></s></span>
                                    <?php endif; ?>
                                    <span class="price"><?php echo e(_formatPrice($p['price'])); ?></span>
                                </span>
                            </div>
                            <div align="left" class="bgr">
                                <a class="addcart btn btn-danger btn-sm" href="<?php echo e(_getAddToCartLink($p['product_content_id'])); ?>">Đặt hàng</a>
                                <a class="detail btn btn-info btn-sm" href="">Xem chi tiết</a>
                            </div>
                        </div>
                    </div>
                    <?php endif; ?>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
        <div class="clearfix"></div>
        <?php endforeach; ?>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script src="/js/slippry.js"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js-init'); ?>
    <script>
        $(function() {
            var slider = $("#gallery").slippry({});
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('front._master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>