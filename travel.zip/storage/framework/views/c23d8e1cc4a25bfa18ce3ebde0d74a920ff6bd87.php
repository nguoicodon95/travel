<?php $__env->startSection('css'); ?>
<style>
  .section {
    padding-top: 0 !important;
  }
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js-init'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="section">
    <div class="container">
        <div class="row">
            <h4 class="group_title"><span>Register successfully</span></h4>
            <hr>
            <div class="row">
                <div class="col-md-12">
                    Merci Levi était possible chez nous. Nous avons reçu vos informations d’enregistrement. Nous avons bientôt vous contactera pour confirmer vos informations de réservation.
                </div>
            </div>
            <div class="row">
                <div class="col-md-12">
                    <a href="<?php echo e(asset('/')); ?>" style="color: #4a90e2; font-weight: bold;"><u>Go Home</u></a>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('front._master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>