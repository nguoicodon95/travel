<?php $__env->startSection('page-toolbar'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="/admin/dist/custom-fields.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script type="text/javascript" src="/admin/dist/pages/custom-fields.js"></script>
    <?php echo $__env->make('admin.custom-fields._custom-field-templates', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js-init'); ?>
    <script type="text/javascript">
        $(document).ready(function () {
            $('.js-validate-form').validate({
                errorElement: 'span', //default input error message container
                errorClass: 'help-block help-block-error', // default input error message class
                focusInvalid: false, // do not focus the last invalid input
                ignore: "",  // validate all fields including form hidden input
                messages: {},
                rules: {
                    title: {
                        minlength: 3,
                        required: true
                    }
                },

                highlight: function (element) {
                    $(element).closest('.form-group').addClass('has-error'); // set error class to the control group
                },

                unhighlight: function (element) {
                    $(element).closest('.form-group').removeClass('has-error'); // set error class to the control group
                },

                success: function (label) {
                    label.closest('.form-group').removeClass('has-error').addClass('has-success'); // set success class to the control group
                }
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-12">
            <div class="note note-danger">
                <p><label class="label label-danger">NOTE</label> You need to enable javascript.</p>
            </div>
            <div class="row">
                <form class="js-validate-form" method="POST" accept-charset="utf-8" action="" novalidate>
                    <?php echo e(csrf_field()); ?>

                    <textarea name="custom_fields_rules" id="custom_fields_rules" class="form-control hidden"
                              style="display: none !important;"><?php echo ((isset($object)) ? $object->field_rules : '[]'); ?></textarea>
                    <textarea name="group_items" id="nestable-output" class="form-control hidden"
                              style="display: none !important;"></textarea>
                    <textarea name="deleted_items" id="deleted_items" class="form-control hidden"
                              style="display: none !important;"></textarea>
                    <div class="col-md-12">
                        <div class="portlet light bordered">
                            <div class="portlet-title">
                                <div class="caption">
                                    <i class="icon-note font-dark"></i>
                                    <span class="caption-subject font-dark sbold uppercase">Basic information</span>
                                </div>
                                <div class="actions">
                                    <div class="btn-group btn-group-devided">
                                        <button class="btn btn-transparent btn-success btn-circle btn-sm active"
                                                type="submit">
                                            <i class="fa fa-check"></i> Save
                                        </button>
                                    </div>
                                </div>
                            </div>
                            <div class="portlet-body">
                                <div class="form-group">
                                    <label><b>Title <span class="text-danger">(*)</span></b></label>
                                    <input required type="text" name="title" class="form-control"
                                           value="<?php echo e(isset($object->title) ? $object->title : ''); ?>" autocomplete="off">
                                </div>
                            </div>
                        </div>
                    </div>
                </form>
                <div class="col-md-12">
                    <?php if(isset($currentID) && $currentID > 0): ?>
                        <div class="portlet light bordered">
                            <div class="portlet-title">
                                <div class="caption">
                                    <i class="icon-note font-dark"></i>
                                    <span class="caption-subject font-dark sbold uppercase">Rules</span>
                                </div>
                            </div>
                            <div class="portlet-body">
                                <div class="row custom-fields-rules">
                                    <div class="col-xs-4 col-md-3">
                                        <p><b>Rules</b></p>
                                        Create a set of rules to determine which edit screens will use these custom
                                        fields
                                    </div>
                                    <div class="col-xs-8 col-md-9">
                                        <p><b>Show this field group if</b></p>
                                        <div class="line-group-container">
                                            <?php echo isset($rulesHtml) ? $rulesHtml : ''; ?>

                                        </div>
                                        <div class="line">
                                            <p class="mar-top-10"><b>Or</b></p>
                                            <a class="location-add-rule-or location-add-rule btn btn-primary" href="#">Add
                                                rule group</a>
                                        </div>
                                    </div>
                                    <div class="clearfix"></div>
                                </div>
                            </div>
                        </div>
                        <div class="portlet light bordered">
                            <div class="portlet-title">
                                <div class="caption">
                                    <i class="icon-note font-dark"></i>
                                    <span class="caption-subject font-dark sbold uppercase">Field items</span>
                                </div>
                            </div>
                            <div class="portlet-body">
                                <div class="custom-fields-list">
                                    <div class="nestable-group">
                                        <?php echo isset($sortableFieldHtml) ? $sortableFieldHtml : ''; ?>

                                    </div>
                                    <div class="clearfix"></div>
                                </div>
                            </div>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin._master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>