<nav class="admin-navbar" id="headerAdminBar">
    <div class="container">
        <div class="logo">
            <a class="navbar-brand" href="/<?php echo e($adminCpAccess); ?>">
                <img src="/admin/theme/images/logo.png" alt="logo" class="logo-default"/>
            </a>
        </div>
        <ul class="admin-navbar-nav">
            <li class="dropdown">
                <a href="/<?php echo e($adminCpAccess); ?>" data-target="#" class="dropdown-toggle"
                   data-toggle="dropdown">Appearance
                    <b class="caret"></b>
                </a>
                <ul class="dropdown-menu">
                    <li>
                        <a target="_blank" href="/<?php echo e($adminCpAccess); ?>/menus">
                            Menus
                        </a>
                    </li>
                    <li>
                        <a target="_blank" href="/<?php echo e($adminCpAccess); ?>/settings">
                            Settings
                        </a>
                    </li>
                </ul>
            </li>
            <li class="dropdown">
                <a href="/<?php echo e($adminCpAccess); ?>" data-target="#" class="dropdown-toggle"
                   data-toggle="dropdown">Add new
                    <b class="caret"></b>
                </a>
                <ul class="dropdown-menu">
                    <li>
                        <a target="_blank" href="/<?php echo e($adminCpAccess); ?>/pages/edit/0">
                            Page
                        </a>
                    </li>
                    <li>
                        <a target="_blank" href="/<?php echo e($adminCpAccess); ?>/posts/edit/0">
                            Post
                        </a>
                    </li>
                    <li>
                        <a target="_blank" href="/<?php echo e($adminCpAccess); ?>/categories/edit/0">
                            Category
                        </a>
                    </li>
                    <li>
                        <a target="_blank" href="/<?php echo e($adminCpAccess); ?>/products/edit/0">
                            Product
                        </a>
                    </li>
                    <li>
                        <a target="_blank" href="/<?php echo e($adminCpAccess); ?>/product-categories/edit/0">
                            Product category
                        </a>
                    </li>
                    <li class="divider"></li>
                    <li>
                        <a target="_blank" href="/<?php echo e($adminCpAccess); ?>/users/edit/0">
                            User
                        </a>
                    </li>
                    <li>
                        <a target="_blank" href="/<?php echo e($adminCpAccess); ?>/admin-users/edit/0">
                            Admin user
                        </a>
                    </li>
                </ul>
            </li>
            <?php if(isset($currentFrontEditLink) && sizeof($currentFrontEditLink) > 0): ?>
                <li>
                    <a target="_blank" href="<?php echo e(isset($currentFrontEditLink['link']) ? $currentFrontEditLink['link'] : ''); ?>" title="<?php echo e(isset($currentFrontEditLink['title']) ? $currentFrontEditLink['title'] : ''); ?>">
                        <?php echo e(isset($currentFrontEditLink['title']) ? $currentFrontEditLink['title'] : ''); ?>

                    </a>
                </li>
            <?php endif; ?>
        </ul>
        <ul class="admin-navbar-nav-right admin-navbar-nav">
            <li class="dropdown">
                <a href="/<?php echo e($adminCpAccess); ?>" data-target="#" class="dropdown-toggle"
                   data-toggle="dropdown"><?php echo e($loggedInAdminUser->username); ?>

                    <b class="caret"></b>
                </a>
                <ul class="dropdown-menu">
                    <li>
                        <a target="_blank" href="/<?php echo e($adminCpAccess); ?>/admin-users/edit/<?php echo e($loggedInAdminUser->id); ?>">
                            Change your password
                        </a>
                    </li>
                    <li class="divider"></li>
                    <li><a href="/<?php echo e($adminCpAccess); ?>/auth/logout">Logout</a></li>
                </ul>
            </li>
        </ul>
    </div>
</nav>
