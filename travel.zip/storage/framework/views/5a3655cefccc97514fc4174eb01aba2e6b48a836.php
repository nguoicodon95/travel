<div class="footer-groups">
    <div class="container">
        <div class="row">
            <div class="col-sm-3">
                <h6 class="footer-lb">À propos de nous</h6>
                <div class="footer-content">
                    <?php echo $a_votre_ecoute; ?>

                </div><!-- footer-content -->
            </div><!-- col -->

            <div class="col-sm-3">
                <h6 class="footer-lb">SITE A DÉCOUVRIR</h6>
                <div class="footer-content">
                    <?php echo $site_a_decouvrir; ?>

                </div><!-- footer-content -->
            </div><!-- col -->

            <div class="col-sm-3">
                <h6 class="footer-lb">NOS CIRCUITS</h6>
                <div class="footer-content">
                    <?php echo $preparez_votre_voyage; ?>

                </div><!-- footer-content -->
            </div><!-- col -->

            <div class="col-sm-3">
                <h6 class="footer-lb">TOP DESTINATIONS</h6>
                <div class="footer-content">
                    <div class="hotline">
                        <span class="hotline-title">Assitance 24/24</span>
                        <span class="hotline-number">(+84) 904 29 35 79</span>
                    </div>
                    <div class="medias">
                        <ul>
                            <li> <a href="<?php echo e(isset($CMSSettings['fb_link']) ? $CMSSettings['fb_link'] : ''); ?>"> <i class="fa fa-facebook" aria-hidden="true"></i></a></li>
                            <li> <a href="<?php echo e(isset($CMSSettings['twiter_link']) ? $CMSSettings['twiter_link'] : ''); ?>"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
                            <li> <a href="<?php echo e(isset($CMSSettings['google_plus_link']) ? $CMSSettings['google_plus_link'] : ''); ?>"> <i class="fa fa-google-plus" aria-hidden="true"></i></a></li>
                            <li> <a href="<?php echo e(isset($CMSSettings['pinterest_link']) ? $CMSSettings['pinterest_link'] : ''); ?>"> <i class="fa fa-pinterest" aria-hidden="true"></i></a></li>
                        </ul>
                    </div>
                </div><!-- footer-content -->
            </div><!-- col -->
        </div><!-- row -->
    </div><!-- container -->
</div><!-- footer-text -->
<div class="copyright">
    <div class="container">
        <div class="row">
            <div class="col-sm-12 address">
                <h6>ACACIA VOYAGE</h6>
                <?php echo isset($CMSSettings['footer_info']) ? $CMSSettings['footer_info'] : ''; ?>

            </div>
        </div><!-- row -->
    </div><!-- container -->
</div><!-- copyright -->
