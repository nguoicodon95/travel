<div class="container">
    <nav class="navbar navbar-default navbar-static-top" role="navigation">
        <div class="row">
            <div class="col-md-12">
                <div class="row">
                    <!-- menu-top -->
                    <!-- <div class="menu-top">
                        <ul>
                            <li><a href="">Blog</a></li>
                            <li><a href="">Video</a></li>
                            <li><a href="">Témoignages</a></li>
                            <li><a href="">Newsletter</a></li>
                            <li><a href="">Nous contacter</a></li>
                        </ul>
                    </div> -->
                    <div class="navbar-header">
                        <!--logo-->
                        <div class="reset-padding-left col-md-3">
                            <a href="/" title="" class="navbar-brand">
                                <img src="<?php echo e(isset($CMSSettings['site_logo']) ? $CMSSettings['site_logo'] : '/images/logo/logo.png'); ?>" alt="<?php echo e(isset($CMSSettings['site_title']) ? $CMSSettings['site_title'] : ''); ?>" />
                            </a>
                        </div>
                        <!--end logo-->
                        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navbar-collapse-rs">
                            <span class="sr-only">Toggle navigation</span>
                            <i class="icon-bar"></i>
                            <i class="icon-bar"></i>
                            <i class="icon-bar"></i>
                        </button>
                        <!--top Search-->
                        <div class="col-md-5">
                            <form action="<?php echo e(route('search', [])); ?>" method="get">
                                <div class="input-group search-group">
                                    <input class="form-control" name="keyword" placeholder="Recherche..." type="text">
                                    <span class="input-group-btn">
                                        <button class="btn btn-primary">Recherche</button>
                                    </span>
                                </div>
                            </form>
                        </div>
                        <!--End top search-->
                        <!-- Hotline -->
                        <div class="hotline">
                            <div class="hotline-title">Assitance 24/24</div>
                            <div class="hotline-number"><?php echo e(isset($CMSSettings['phone']) ? $CMSSettings['phone'] : ''); ?></div>
                        </div>
                        <!-- End hotline -->
                    </div>
                </div>
            </div>
            <!-- Navigation -->
            <div class="col-md-10">
                <div class="collapse navbar-collapse" id="navbar-collapse-rs">
                    <?php echo $mega_menu; ?>

                </div>
            </div>
            <div class="col-md-2 medias reset-padding-right">
                <ul>
                    <li> <a href="<?php echo e(isset($CMSSettings['fb_link']) ? $CMSSettings['fb_link'] : ''); ?>"> <i class="fa fa-facebook" aria-hidden="true"></i></a></li>
                    <li> <a href="<?php echo e(isset($CMSSettings['twiter_link']) ? $CMSSettings['twiter_link'] : ''); ?>"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
                    <li> <a href="<?php echo e(isset($CMSSettings['google_plus_link']) ? $CMSSettings['google_plus_link'] : ''); ?>"> <i class="fa fa-google-plus" aria-hidden="true"></i></a></li>
                    <li> <a href="<?php echo e(isset($CMSSettings['pinterest_link']) ? $CMSSettings['pinterest_link'] : ''); ?>"> <i class="fa fa-pinterest" aria-hidden="true"></i></a></li>
                </ul>
            </div>
        </div>
    </nav>
</div>
