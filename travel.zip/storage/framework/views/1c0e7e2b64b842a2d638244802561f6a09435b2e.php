<div class="line" data-option="placeholdertext">
    <div class="col-xs-3">
        <h5>Placeholder Text</h5>
        <p>Appears within the input</p>
    </div>
    <div class="col-xs-9">
        <h5>Placeholder Text</h5>
        <input type="text" class="form-control" placeholder="" value="<?php echo e(isset($options->placeholdertext) ? $options->placeholdertext : ''); ?>">
    </div>
    <div class="clearfix"></div>
</div>