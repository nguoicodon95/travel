<div class="add-new-field">
    <ul class="list-group field-table-header">
        <li class="col-xs-4 list-group-item w-bold">Field Label</li>
        <li class="col-xs-4 list-group-item w-bold">Field Name</li>
        <li class="col-xs-4 list-group-item w-bold">Field Type</li>
        <li class="clearfix"></li>
    </ul>
    <div class="clearfix"></div>
    <ul class="sortable-wrapper mar-bot-10">
        <?php foreach($fieldItems as $key => $row): ?>
            <li class="ui-sortable-handle"
                data-position="<?php echo e($key + 1); ?>"
                data-repeateritems=""
                data-options=""
                data-id="<?php echo e(isset($row->id) ? $row->id : ''); ?>"
                data-name="<?php echo e(isset($row->slug) ? $row->slug : ''); ?>"
                data-title="<?php echo e(isset($row->title) ? $row->title : ''); ?>"
                data-type="<?php echo e(isset($row->field_type) ? $row->field_type : ''); ?>"
                data-instructions="<?php echo e(isset($row->instructions) ? $row->instructions : ''); ?>">
                <div class="field-column">
                    <div class="text col-xs-4 field-label"><?php echo e(((trim($row->title) != '') ? $row->title : '&nbsp;')); ?></div>
                    <div class="text col-xs-4 field-name"><?php echo e(((trim($row->slug) != '') ? $row->slug : '&nbsp;')); ?></div>
                    <div class="text col-xs-4 field-type"><?php echo e(((trim($row->field_type) != '') ? $row->field_type : '&nbsp;')); ?></div>
                    <a class="show-item-details" title="" href="#"><i class="fa fa-angle-down"></i></a>
                    <div class="clearfix"></div>
                </div>
                <div class="item-details">
                    <div class="line" data-option="title">
                        <div class="col-xs-3">
                            <h5>Field Label</h5>
                            <p>This is the name which will appear on the EDIT page</p>
                        </div>
                        <div class="col-xs-9">
                            <h5>Field Label</h5>
                            <input type="text" class="form-control" placeholder="" value="<?php echo e(isset($row->title) ? $row->title : ''); ?>">
                        </div>
                        <div class="clearfix"></div>
                    </div>
                    <div class="line" data-option="instructions">
                        <div class="col-xs-3">
                            <h5>Field Instructions</h5>
                            <p>Instructions for authors. Shown when submitting data</p>
                        </div>
                        <div class="col-xs-9">
                            <h5>Field Instructions</h5>
                            <input type="text" class="form-control" placeholder=""
                                   value="<?php echo e(isset($row->instructions) ? $row->instructions : ''); ?>">
                        </div>
                        <div class="clearfix"></div>
                    </div>
                    <div class="line" data-option="name">
                        <div class="col-xs-3">
                            <h5>Field Name</h5>
                            <p>Single word, no spaces. Underscores and dashes allowed</p>
                        </div>
                        <div class="col-xs-9">
                            <h5>Field Name</h5>
                            <input type="text" class="form-control" placeholder="" value="<?php echo e(isset($row->slug) ? $row->slug : ''); ?>">
                        </div>
                        <div class="clearfix"></div>
                    </div>
                    <div class="line" data-option="type">
                        <div class="col-xs-3"><h5>Field Type</h5></div>
                        <div class="col-xs-9">
                            <h5>Field Type</h5>
                            <select name="" class="form-control change-field-type">
                                <optgroup label="Basic">
                                    <option value="text" <?php echo e((($row->field_type == 'text') ? ' selected="selected"' : '')); ?>>
                                        Text
                                    </option>
                                    <option value="textarea" <?php echo e((($row->field_type == 'textarea') ? ' selected="selected"' : '')); ?>>
                                        Textarea
                                    </option>
                                    <option value="number" <?php echo e((($row->field_type == 'number') ? ' selected="selected"' : '')); ?>>
                                        Number
                                    </option>
                                    <option value="email" <?php echo e((($row->field_type == 'email') ? ' selected="selected"' : '')); ?>>
                                        Email
                                    </option>
                                    <option value="password" <?php echo e((($row->field_type == 'password') ? ' selected="selected"' : '')); ?>>
                                        Password
                                    </option>
                                </optgroup>
                                <optgroup label="Content">
                                    <option value="wyswyg" <?php echo e((($row->field_type == 'wyswyg') ? ' selected="selected"' : '')); ?>>
                                        WYSIWYG editor
                                    </option>
                                    <option value="image" <?php echo e((($row->field_type == 'image') ? ' selected="selected"' : '')); ?>>
                                        Image
                                    </option>
                                    <option value="file" <?php echo e((($row->field_type == 'file') ? ' selected="selected"' : '')); ?>>
                                        File
                                    </option>
                                </optgroup>
                                <optgroup label="Choice">
                                    <option value="select" <?php echo e((($row->field_type == 'select') ? ' selected="selected"' : '')); ?>>
                                        Select
                                    </option>
                                    <option value="checkbox" <?php echo e((($row->field_type == 'checkbox') ? ' selected="selected"' : '')); ?>>
                                        Checkbox
                                    </option>
                                    <option value="radio" <?php echo e((($row->field_type == 'radio') ? ' selected="selected"' : '')); ?>>
                                        Radio button
                                    </option>
                                </optgroup>
                                <?php if(isset($isRepeater) && !$isRepeater): ?>
                                    <optgroup label="Other">
                                        <option value="repeater" <?php echo e((($row->field_type == 'repeater') ? ' selected="selected"' : '')); ?>>
                                            Repeater
                                        </option>
                                    </optgroup>
                                <?php endif; ?>
                            </select>
                        </div>
                        <div class="clearfix"></div>
                    </div>
                    <div class="options">
                        <?php if($row->field_type == 'repeater'): ?>
                            <div class="line" data-option="repeater">
                                <div class="col-xs-3">
                                    <h5>Repeater fields</h5>
                                </div>
                                <div class="col-xs-9">
                                    <h5>Repeater fields</h5>
                                    <?php echo $__env->make('admin._partials.custom-fields._field-group-items', ['fieldItems' => $row->child()->orderBy('position', 'ASC')->get(), 'isRepeater' => true, 'object' => $object], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                                </div>
                                <div class="clearfix"></div>
                            </div>
                        <?php endif; ?>
                        <?php echo $object->_getOptionCustomFields($row->field_type, json_decode($row->options), $row->id); ?>

                    </div>
                    <div class="text-right pad-top-10 pad-bot-10 pad-rig-10">
                        <a class="btn red btn-remove" title="" href="#">Remove</a>
                        <a class="btn blue btn-close-field" title="" href="#">Close fields</a>
                    </div>
                </div>
            </li>
        <?php endforeach; ?>
    </ul>
    <div class="text-right">
        <a class="btn red btn-add-field" title="" href="<?php echo e((!$isRepeater) ? '#nestable > .dd-list' : 'repeater'); ?>"
           id="">Add field</a>
    </div>
</div>