<?php $__env->startSection('css'); ?>
<style>
  .active a {
    color: #fff;
  }
  .section.catalog-section h2 {
    float: none;
  }
  .section.catalog-section h2.group_title {
    position: relative;
  }
  <?php echo $__env->make('front._modules.style_post', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js-init'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="section catalog-section">
    <div class="container">
        <div class="row">
            <div class="col-md-4">
              <h2><?php echo e(isset($catalog['root']) ? $catalog['root'] : ''); ?></h2>
              <div class="panel-group panel panel-default" id="accordion">
                <?php if(!empty($catalog['child_catalog'])): ?>
                  <?php foreach($catalog['child_catalog'] as $key => $catalog): ?>
                    <div class="panel">
                        <div class="panel-heading">
                          <h4 class="panel-title">
                            <a href="<?php echo e(_getCategoryLinkWithParentSlugs($catalog->id)); ?>">
                              <?php echo e($catalog->title); ?>

                            </a>
                            <?php if($catalog->child()->count() > 0): ?>
                            <span style="cursor: pointer" class="accordion-toggle pull-right" data-toggle="collapse" data-parent="#accordion" href="#collapseOne"> -- </span>
                            <?php endif; ?>
                          </h4>
                        </div>
                        <div id="collapseOne" class="panel-collapse collapse <?php echo e(($object->parent_id != 0) && $object->parent->slug == $catalog->slug ? 'in' : ''); ?>">
                            <?php if($catalog->child()->count() > 0): ?>
                            <ul class="list-group">
                              <?php foreach( $catalog->child as $child_of_child ): ?>
                                <li class="list-group-item <?php echo e($catalog_current == $child_of_child->slug ? 'active' : ''); ?>"><a href="<?php echo e(_getCategoryLinkWithParentSlugs($child_of_child->id)); ?>">- <?php echo e($child_of_child->title); ?></a></li>
                              <?php endforeach; ?>
                            </ul>
                            <?php endif; ?>
                        </div>
                    </div>
                  <?php endforeach; ?>
                <?php endif; ?>
               </div>
            </div>
            <div class="col-md-8">
                <h2 class="group_title"><?php echo e($object->title); ?></h2>
                <div class="list-grid">
                  <?php if(!empty($posts)): ?>
                    <?php foreach($posts as $post): ?>
                    <div class="grid row">
                        <div class="col-md-5 reset-padding-left">
                            <div class="thumbnail">
                                <a href="<?php echo e(_getPostLink($post->slug)); ?>">
                                    <img class="image-background image-full" src="/images/libraries/trans.png" style="background-image: url('<?php echo e($post->thumbnail); ?>');" alt="<?php echo e(isset($post->title) ? $post->title : ''); ?>" title="<?php echo e(isset($post->title) ? $post->title : ''); ?>" />
                                </a>
                            </div>
                        </div>
                        <div class="col-md-7">
                            <div class="post-title">
                                <a href="<?php echo e(_getPostLink($post->slug)); ?>" title="<?php echo e(isset($post->title) ? $post->title : ''); ?>"><?php echo e(isset($post->title) ? $post->title : ''); ?></a>
                            </div>
                            <div class="post-desc"><?php echo e(isset($post->description) ? $post->description : ''); ?></div>
                            <div class="post-catalog">
                                <span class="pull-left fb13">Publié dans:</span><a href="<?php echo e(_getCategoryLinkWithParentSlugs($post->cate_id)); ?>"> <?php echo e(isset($post->cate_title) ? $post->cate_title : ''); ?></a>
                                <a href="#" class="pull-right readmore">En savoir &raquo;</a>
                                <div class="clearfix"></div>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; ?>
                  <?php endif; ?>
                </div>

                <div align="center">
                    <?php echo $posts->setPath(asset(Request::path()))->appends(Request::query())->render(); ?>

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('front._master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>