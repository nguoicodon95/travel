<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title><?php echo e($data['subject']); ?></title>
  </head>
  <body>
      <h2 style="font-size: 17px;"><?php echo e($data['subject']); ?></h2>
      <p>
        Có 1 yêu cầu từ người sử dụng <strong><?php echo e($data['name']); ?>:</strong>
      </p>
      <h3>Nội dung yêu cầu:</h3>
      <p>
        <?php echo e($data['content']); ?>

      </p>

      <h3>Thông tin liên hệ của <?php echo e($data['name']); ?></h3>
      <table style="border: 0">
          <tr>
            <td style="width: 250px;">
              Số điện thoại:
            </td>
            <td>
              <?php echo e($data['phone']); ?>

            </td>
          </tr>
          <tr>
            <td style="width: 250px;">
              Email:
            </td>
            <td>
              <?php echo e($data['email']); ?>

            </td>
          </tr>
      </table>
  </body>
</html>
