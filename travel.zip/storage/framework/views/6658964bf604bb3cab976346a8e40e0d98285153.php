<meta charset="utf-8"/>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<meta http-equiv="content-language" content="<?php echo e(isset($currentLanguageCode) ? $currentLanguageCode : 'en'); ?>"/>
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta content="width=device-width, initial-scale=1" name="viewport"/>
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

<title><?php echo e(isset($pageTitle) ? $pageTitle : 'Trang chủ'); ?> | <?php echo e(isset($CMSSettings['site_title']) ? $CMSSettings['site_title'] : ''); ?></title>
<meta name="description" content="<?php echo e(isset($metaSEO['description']) ? $metaSEO['description'] : ''); ?>"/>
<meta name="keywords" content="<?php echo e(isset($metaSEO['keywords']) ? $metaSEO['keywords'] : ''); ?>"/>
<meta content="<?php echo e(isset($CMSSettings['email']) ? $CMSSettings['email'] : ''); ?>" name="author"/>

<!-- Google+ -->
<meta itemprop="name" content="<?php echo e(isset($pageTitle) ? $pageTitle : ''); ?> | <?php echo e(isset($CMSSettings['site_title']) ? $CMSSettings['site_title'] : ''); ?>">
<meta itemprop="description" content="<?php echo e(isset($metaSEO['description']) ? $metaSEO['description'] : ''); ?>">
<meta itemprop="keywords" content="<?php echo e(isset($metaSEO['keywords']) ? $metaSEO['keywords'] : ''); ?>">
<meta itemprop="image" content="<?php echo e(isset($metaSEO['image']) ? $metaSEO['image'] : ''); ?>">

<!-- Twitter Card data -->
<meta name="twitter:card" content="<?php echo e(isset($metaSEO['image']) ? $metaSEO['image'] : ''); ?>">
<meta name="twitter:site" content="<?php echo e(Request::url()); ?>">
<meta name="twitter:title" content="<?php echo e(isset($pageTitle) ? $pageTitle : ''); ?> | <?php echo e(isset($CMSSettings['site_title']) ? $CMSSettings['site_title'] : ''); ?>">
<meta name="twitter:description" content="<?php echo e(isset($metaSEO['description']) ? $metaSEO['description'] : ''); ?>">
<meta name="twitter:creator" content="">
<!-- Twitter summary card with large image must be at least 280x150px -->
<meta name="twitter:image:src" content="<?php echo e(isset($metaSEO['image']) ? $metaSEO['image'] : ''); ?>">

<!-- Open Graph data -->
<meta property="og:title" content="<?php echo e(isset($pageTitle) ? $pageTitle : ''); ?> | <?php echo e(isset($CMSSettings['site_title']) ? $CMSSettings['site_title'] : ''); ?>"/>
<meta property="og:type" content="article"/>
<meta property="og:url" content="<?php echo e(Request::url()); ?>"/>
<meta property="og:image" content="<?php echo e(isset($metaSEO['image']) ? $metaSEO['image'] : ''); ?>"/>
<meta property="og:description" content="<?php echo e(isset($metaSEO['description']) ? $metaSEO['description'] : ''); ?>"/>
<meta property="og:site_name" content="<?php echo e(isset($CMSSettings['site_title']) ? $CMSSettings['site_title'] : ''); ?>"/>
<meta property="article:published_time"
      content="<?php echo e((isset($object) && isset($object->created_at)) ? $object->created_at : date('Y-m-d H:i:s')); ?>"/>
<meta property="article:modified_time"
      content="<?php echo e((isset($object) && isset($object->updated_at)) ? $object->updated_at : date('Y-m-d H:i:s')); ?>"/>
<meta property="article:section" content="<?php echo e(isset($pageTitle) ? $pageTitle : $CMSSettings['site_title']); ?>"/>
<meta property="article:tag" content="<?php echo e(isset($metaSEO['keywords']) ? $metaSEO['keywords'] : ''); ?>"/>
<meta property="fb:admins" content=""/>
