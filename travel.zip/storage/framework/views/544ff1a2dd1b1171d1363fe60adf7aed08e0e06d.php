<?php $__env->startPush('style'); ?>
<style>
    .list-grid .grid {
        border-bottom: 1px solid #e3e3e3;
        margin: 0 0 30px;
    }
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('js'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js-init'); ?>
   
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="section catalog-section">
    <div class="container">
        <div class="row">
            <div class="col-md-4">
                <div class="panel-group panel panel-default" id="accordion">
                    <?php echo $menu_left_on_search_page; ?>

                </div>
            </div>
            <?php if(isset($posts) && !empty($posts)): ?>
            <div class="col-md-8">
                <h4 style="margin-top: 0"><span>Il y a <strong><?php echo e($count_posts); ?></strong> résultats pour mot clé <strong>"<?php echo e(Request::get('keyword')); ?>"</strong></span></h4>
                <form action="<?php echo e(route('search', [])); ?>" method="get">
                    <div class="input-group">
                        <input type="text" name="keyword" class="form-control" placeholder="Recherche...">
                        <span class="input-group-btn">
                            <button class="btn">Recherche</button>
                        </span>
                    </div>
                </form>
                <hr>
                <div class="list-grid">
                    <?php foreach($posts as $post): ?>
                    <div class="grid row">
                        <div class="col-md-5 reset-padding-all">
                            <div class="thumbnail">
                                <a href="<?php echo e(_getPostLink($post->slug)); ?>">
                                    <img class="image-background image-full" src="/images/libraries/trans.png" style="background-image: url('<?php echo e($post->thumbnail); ?>');" alt="<?php echo e(isset($post->title) ? $post->title : ''); ?>" title="<?php echo e(isset($post->title) ? $post->title : ''); ?>" />
                                </a>
                            </div>
                        </div>
                        <div class="col-md-7">
                            <div class="post-title">
                                <a href="<?php echo e(_getPostLink($post->slug)); ?>" title="<?php echo e(isset($post->title) ? $post->title : ''); ?>"><?php echo e(isset($post->title) ? $post->title : ''); ?></a>
                            </div>
                            <div class="post-desc"><?php echo e(isset($post->description) ? $post->description : ''); ?></div>
                            <div class="post-catalog">
                                <span class="pull-left fb13">Publié dans:</span><a href="<?php echo e(_getCategoryLinkWithParentSlugs($post->cate_id)); ?>"> <?php echo e(isset($post->cate_title) ? $post->cate_title : ''); ?></a>
                                <a href="#" class="pull-right readmore">En savoir &raquo;</a>
                                <div class="clearfix"></div>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
                <div align="center">
                    <?php echo $posts->setPath(asset(Request::path()))->appends(Request::query())->render(); ?>

                </div>
            </div>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('front._master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>