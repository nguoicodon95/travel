<!-- BEGIN SIDEBAR -->
{!! $CMSMenuHtml or '' !!}
<!-- END SIDEBAR -->
