<div class="scf-text-wrap">
    <input type="email" data-fieldtype="{{ $fieldItem->field_type_updated or '' }}" data-slug="{{ $fieldItem->slug or '' }}"
           value="{{ $theMeta or '' }}" placeholder="{{ $options->placeholdertext or '' }}" class="form-control">
</div>