@extends('front._master')

@section('css')
<style>
  .active a {
    color: #fff;
  }
  .section.catalog-section h2 {
    float: none;
  }
  .section.catalog-section h2.group_title {
    position: relative;
  }
  @include('front._modules.style_post')
</style>
@endsection

@section('js')

@endsection

@section('js-init')

@endsection

@section('content')
<div class="section catalog-section">
    <div class="container">
        <div class="row">
            <div class="col-md-4">
              <h2>{{ $catalog['root'] or '' }}</h2>
              <div class="panel-group panel panel-default" id="accordion">
                @if(!empty($catalog['child_catalog']))
                  @foreach($catalog['child_catalog'] as $key => $catalog)
                    <div class="panel">
                        <div class="panel-heading">
                          <h4 class="panel-title">
                            <a href="{{ _getCategoryLinkWithParentSlugs($catalog->id) }}">
                              {{ $catalog->title }}
                            </a>
                            @if($catalog->child()->count() > 0)
                            <span style="cursor: pointer" class="accordion-toggle pull-right" data-toggle="collapse" data-parent="#accordion" href="#collapseOne"> -- </span>
                            @endif
                          </h4>
                        </div>
                        <div id="collapseOne" class="panel-collapse collapse {{ ($object->parent_id != 0) && $object->parent->slug == $catalog->slug ? 'in' : '' }}">
                            @if($catalog->child()->count() > 0)
                            <ul class="list-group">
                              @foreach( $catalog->child as $child_of_child )
                                <li class="list-group-item {{ $catalog_current == $child_of_child->slug ? 'active' : '' }}"><a href="{{ _getCategoryLinkWithParentSlugs($child_of_child->id) }}">- {{ $child_of_child->title }}</a></li>
                              @endforeach
                            </ul>
                            @endif
                        </div>
                    </div>
                  @endforeach
                @endif
               </div>
            </div>
            <div class="col-md-8">
                <h2 class="group_title">{{ $object->title }}</h2>
                <div class="list-grid">
                  @if(!empty($posts))
                    @foreach($posts as $post)
                    <div class="grid row">
                        <div class="col-md-5 reset-padding-left">
                            <div class="thumbnail">
                                <a href="{{ _getPostLink($post->slug) }}">
                                    <img class="image-background image-full" src="/images/libraries/trans.png" style="background-image: url('{{ $post->thumbnail }}');" alt="{{ $post->title or '' }}" title="{{ $post->title or '' }}" />
                                </a>
                            </div>
                        </div>
                        <div class="col-md-7">
                            <div class="post-title">
                                <a href="{{ _getPostLink($post->slug) }}" title="{{ $post->title or '' }}">{{ $post->title or '' }}</a>
                            </div>
                            <div class="post-desc">{{ $post->description or '' }}</div>
                            <div class="post-catalog">
                                <span class="pull-left fb13">Publié dans:</span><a href="{{ _getCategoryLinkWithParentSlugs($post->cate_id) }}"> {{ $post->cate_title or '' }}</a>
                                <a href="#" class="pull-right readmore">En savoir &raquo;</a>
                                <div class="clearfix"></div>
                            </div>
                        </div>
                    </div>
                    @endforeach
                  @endif
                </div>

                <div align="center">
                    {!! $posts->setPath(asset(Request::path()))->appends(Request::query())->render() !!}
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
