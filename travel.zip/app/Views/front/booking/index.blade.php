@extends('front._master')

@section('css')
  <style>
      .main-wrapper {
          margin-bottom: 10px;
      }
  </style>
@endsection

@section('js')
  <script src="//ajax.aspnetcdn.com/ajax/jquery.validate/1.9/jquery.validate.min.js"></script>
@endsection

@section('js-init')
<script>
	$.validator.addMethod("regx", function(value, element, regexpr) {
	    return regexpr.test(value);
	}, "Số điện thoại không hợp lệ.");
	$(function() {
	    $("#_form_confirm").validate({
	        rules: {
	            booking_address: "required",
	            booking_name: {
	                required: true,
  	            	minlength: 2,
	            },
	            booking_phone: {
	            	required: true,
      					number: true,
      					regx: /^(0|\+[0-9]{1,5})([1-9][0-9]{8}?([0-9]{0,1}))$/,
	            },
	            booking_email: {
	                required: true,
	                email: true
	            },
	        },
	        messages: {
	        },
	        submitHandler: function(form) {
            alert(1)
	            $(form).submit();
	        }
	    });
});
</script>
@endsection
@section('content')
    <h4 class="group_title"><span>THÔNG TIN ĐẶT HÀNG</span></h4>
    <div class="row">
        <div class="form-group col-md-6">
            <input type="text" class="form-control" id="name" name="name" placeholder="Họ và tên" required>
            <input type="email" class="form-control" id="email" name="email" placeholder="E-mail" required>
            <input type="text" class="form-control" pattern="^(0|\+[0-9]{1,5})([1-9][0-9]{8}?([0-9]{0,1}))$" id="phone" name="phone" placeholder="Số điện thoại" required>
            <input type="text" class="form-control" id="address" name="address" placeholder="Địa chỉ liên hệ" required>
        </div>
        <div class="col-md-6">
            <textarea name="note" cols="30" rows="10" class="form-control"></textarea>
        </div>
        <div class="col-md-12">
            <button type="submit" class="btn btn-primary">Gửi đơn hàng</button>
        </div>
    </div>
@endsection
